#include <stdlib.h>
#include <stdio.h>
#include "LineParser.c"
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <sys/stat.h> 
#include <fcntl.h>


char *getcwd(char *buf, size_t size);
void execute(cmdLine *pCmdLine);
int execv(const char *path, char *const argv[]);
pid_t waitpid(pid_t pid, int *status, int options);
int debugMode=0;

int main(int argc, char** argv){
    pid_t child_pid;
    int ret;
    char buf[2048];
    char* wd;

    for(int i=0; i<argc;i++){
        if(strcmp(argv[i],"-d")==0){
            debugMode=1;
        }
    }
   
    //main loop
    while(1){
        wd= getcwd(buf,PATH_MAX);
        printf("%s\n",wd); 
        fgets(buf,2048,stdin); 
        cmdLine* line = parseCmdLines(buf);
        if(strncmp(buf,"quit",4)==0){
            exit(0);
        }
        else if(strncmp(buf,"cd",2)==0 ){
            buf[strlen (buf) - 1] = '\0'; //remove '\n'
            ret = chdir ((buf+3));
            if(ret!=0)
                perror("chdir");          
        }
        
        else{
            child_pid=fork(); 
            if(child_pid==0)
            {
                if(line->inputRedirect!=NULL){
                    fclose(stdin);
                    fopen(line->inputRedirect,"r");
                     }
                if(line->outputRedirect!=NULL){
                    fclose(stdout);
                    fopen(line->outputRedirect,"w");
                }
                execute(line);
            }
            else{ //parent
                if(line->blocking==1){
                    waitpid(child_pid,NULL,0); // wait for child process to terminate 
                }
                freeCmdLines(line);
            }
        }
    }
    return 0;
}

void execute(cmdLine *pCmdLine){
    if(debugMode==1){
        fprintf(stderr,"Pid: %d\n",getpid());
        fprintf(stderr,"Executing command: %s\n",pCmdLine->arguments[0]);
    }
   execvp(pCmdLine->arguments[0],pCmdLine->arguments);
    perror("execv");
    exit(1);
 }


