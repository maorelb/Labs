#include<stdio.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<string.h> 
#include<sys/wait.h> 

int main(int argc, char** argv){
    int fd[2];
    pid_t cpid1,cpid2;
    int duplicated_fd,debug=0;

    for(int i=0; i<argc;i++){
        if(strcmp(argv[i],"-d")==0){
            debug=1;
        }
    }
    if(pipe(fd)==-1){
        perror("pipe");
        exit(EXIT_FAILURE);
    }
    if(debug==1)
        fprintf(stderr,"parent_process>forking…\n");
    
    cpid1=fork();
    if(debug==1 && cpid1!=0)
        fprintf(stderr,"parent_process>created process with id: %d\n",cpid1);
    if(cpid1==-1){
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if(cpid1==0){
        close(STDOUT_FILENO);
        if(debug==1)
            fprintf(stderr,"child1>redirecting stdout to the write end of the pipe…\n");
        duplicated_fd=dup(fd[1]); //duplicate write end of the pipe
        if(duplicated_fd==-1){
            perror("dup");
            exit(EXIT_FAILURE);
        }
        close(fd[1]);
        char *argv[3];
        argv[0]="ls";
        argv[1]="-l";
        argv[2]=NULL;
        if(debug==1)
            fprintf(stderr,"going to execute cmd: …\n");
        execvp("ls",argv);
        perror("execv");
        exit(EXIT_FAILURE);
    }
    else{
        if(debug==1)
            fprintf(stderr,"parent_process>closing the write end of the pipe…\n");
        close(fd[1]); //closing write end - if it is marked the parent is blocked
        if(debug==1)
            fprintf(stderr,"parent_process>forking…\n");
        cpid2=fork();
        if(debug==1 && cpid2!=0)
            fprintf(stderr,"parent_process>created process with id: %d\n",cpid2);
        if(cpid2==-1){
            perror("fork");
            exit(EXIT_FAILURE);
        }
        if(cpid2==0){
            close(STDIN_FILENO);
            if(debug==1)
                fprintf(stderr,"child2>redirecting stdin to the read end of the pipe…\n");
            duplicated_fd=dup(fd[0]); //duplicate read end of the pipe
            if(duplicated_fd==-1){
                perror("dup");
                exit(EXIT_FAILURE);
            }
            close(fd[0]);
            char *argv[4];
            argv[0]="tail";
            argv[1]="-n";
            argv[2]="2";
            argv[3]=NULL;
            if(debug==1)
                fprintf(stderr,"going to execute cmd: …\n");
            execvp("tail",argv);
            perror("execv");
            exit(EXIT_FAILURE);
        }
        else{
            if(debug==1)
                fprintf(stderr,"parent_process>closing the read end of the pipe…\n");
            close(fd[0]); //close read end - does not effect if marked
            if(debug==1)
                fprintf(stderr,"parent_process>waiting for child processes number %d to terminate…\n",cpid1);
            waitpid(cpid1,NULL,0);      //wait for child1
            if(debug==1)
                fprintf(stderr,"parent_process>waiting for child processes number %d to terminate…\n",cpid2);
            waitpid(cpid2,NULL,0);       //wait for child2
        }
    }
    fprintf(stderr,"parent_process>exiting…\n");
    exit(0);
}

//https://stackoverflow.com/questions/33626192/what-happens-if-we-do-not-close-the-used-end-in-pipe-linux-c