#include <stdlib.h>
#include <stdio.h>
#include "LineParser.c"
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <sys/stat.h> 
#include <fcntl.h>


char *getcwd(char *buf, size_t size);
void execute(cmdLine *pCmdLine);
int execv(const char *path, char *const argv[]);
pid_t waitpid(pid_t pid, int *status, int options);
void pipe_and_execute(cmdLine* cmd, cmdLine *next);
void replace_Variables(cmdLine* line);
void delete(char* varName);
int debug=0;


typedef struct variable{
    char* name;
    char* value;
}variable;

typedef struct var_link var_link;
typedef struct var_link{
    variable* var;
    var_link* next;
}var_link;

var_link* head=NULL;
var_link* search(char* name);


int main(int argc, char** argv){
    pid_t child_pid;
    char buf[2048];
    char* wd;

    for(int i=0; i<argc;i++){
        if(strcmp(argv[i],"-d")==0){
            debug=1;
        }
    }
   
    //main loop
    while(1){
        wd= getcwd(buf,PATH_MAX);
        printf("%s\n",wd); 
        fgets(buf,2048,stdin); 
        cmdLine* line = parseCmdLines(buf);
        replace_Variables(line);
        if(strncmp(buf,"quit",4)==0){
            exit(0);
        }
        else if(strncmp(line->arguments[0],"cd",2)==0){
            if(strncmp(line->arguments[1],"~",1)==0){
                if(chdir(getenv("HOME"))!=0){
                    perror("getenv");
                    exit(EXIT_FAILURE);
                }
            }
            else{
                chdir(line->arguments[1]);
            }
            freeCmdLines(line);
        }
        else if(strncmp(line->arguments[0],"set",3)==0){
            var_link* l=search(line->arguments[1]);
            //variable name exists
            if(l!=NULL){
                free(l->var->value);
                l->var->value=malloc(strlen(line->arguments[2])+1);
                strcpy(l->var->value,line->arguments[2]);
            }
            else{
                variable* v=malloc(sizeof(variable));
                v->name=line->arguments[1];
                v->value=line->arguments[2];
                var_link* new_link=malloc(sizeof(var_link));
                new_link->var=v;
                new_link->next=NULL;
                if(head==NULL)
                    head=new_link;
                else{
                    var_link* curr=head;
                    while(curr->next!=NULL){
                        curr=curr->next;
                    }
                    curr->next=new_link;
                }
            }
        }
        else if(strncmp(line->arguments[0],"vars",4)==0){
            if(head==NULL){
                continue;
            }
            else{
                var_link* curr=head;
                while(curr!=NULL){
                    printf("( %s , %s )\n",curr->var->name,curr->var->value);
                    curr=curr->next;
                }
           }
        }
        else if(strncmp(line->arguments[0],"delete",6)==0){
            delete(line->arguments[1]);
        }
        
        else{
            if(line->next!=NULL)
                pipe_and_execute(line,line->next);
            else{
                child_pid=fork(); 
                if(child_pid==0)
                {
                    if(line->inputRedirect!=NULL){
                        fclose(stdin);
                        fopen(line->inputRedirect,"r");
                        }
                    if(line->outputRedirect!=NULL){
                        fclose(stdout);
                        fopen(line->outputRedirect,"w");
                    }
                    execute(line);
                }
                else{ //parent
                    if(line->blocking==1){
                        waitpid(child_pid,NULL,0); // wait for child process to terminate 
                    }
                    freeCmdLines(line);
                }
            }
        }
    }
    return 0;
}

void execute(cmdLine *pCmdLine){
    if(debug==1){
        fprintf(stderr,"Pid: %d\n",getpid());
        fprintf(stderr,"Executing command: %s\n",pCmdLine->arguments[0]);
    }
   execvp(pCmdLine->arguments[0],pCmdLine->arguments);
    perror("execv");
    exit(1);
 }

 void pipe_and_execute(cmdLine* cmd, cmdLine *next){
    int fd[2];
    pid_t cpid1,cpid2;
    int duplicated_fd,debug=0;

   if(pipe(fd)==-1){
        perror("pipe");
        exit(EXIT_FAILURE);
    }
    if(debug==1)
        fprintf(stderr,"parent_process>forking…\n");
    
    cpid1=fork();
    if(debug==1 && cpid1!=0)
        fprintf(stderr,"parent_process>created process with id: %d\n",cpid1);
    if(cpid1==-1){
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if(cpid1==0){
        close(STDOUT_FILENO);
        if(debug==1)
            fprintf(stderr,"child1>redirecting stdout to the write end of the pipe…\n");
        duplicated_fd=dup(fd[1]); //duplicate write end of the pipe
        if(duplicated_fd==-1){
            perror("dup");
            exit(EXIT_FAILURE);
        }
        close(fd[1]);
        if(debug==1)
            fprintf(stderr,"going to execute cmd: …\n");
        execvp(cmd->arguments[0],cmd->arguments);
        perror("execv");
        exit(EXIT_FAILURE);
    }
    else{
        if(debug==1)
            fprintf(stderr,"parent_process>closing the write end of the pipe…\n");
        close(fd[1]); //closing write end - if it is marked the parent is blocked
        if(debug==1)
            fprintf(stderr,"parent_process>forking…\n");
        cpid2=fork();
        if(debug==1 && cpid2!=0)
            fprintf(stderr,"parent_process>created process with id: %d\n",cpid2);
        if(cpid2==-1){
            perror("fork");
            exit(EXIT_FAILURE);
        }
        if(cpid2==0){
            close(STDIN_FILENO);
            if(debug==1)
                fprintf(stderr,"child2>redirecting stdin to the read end of the pipe…\n");
            duplicated_fd=dup(fd[0]); //duplicate read end of the pipe
            if(duplicated_fd==-1){
                perror("dup");
                exit(EXIT_FAILURE);
            }
            close(fd[0]);
            if(debug==1)
                fprintf(stderr,"going to execute cmd: …\n");
            execvp(next->arguments[0],next->arguments);
            perror("execv");
            exit(EXIT_FAILURE);
        }
        else{
            if(debug==1)
                fprintf(stderr,"parent_process>closing the read end of the pipe…\n");
            close(fd[0]); //close read end - does not effect if marked
            if(debug==1)
                fprintf(stderr,"parent_process>waiting for child processes number %d to terminate…\n",cpid1);
            waitpid(cpid1,NULL,0);      //wait for child1
            if(debug==1)
                fprintf(stderr,"parent_process>waiting for child processes number %d to terminate…\n",cpid2);
            waitpid(cpid2,NULL,0);       //wait for child2
        }
    }
 }

 var_link* search(char* name){
     var_link* curr=head;
     while(curr!=NULL){
         if(strcmp(curr->var->name,name)==0)
            return curr;
        curr=curr->next;
     }
     return NULL;
 }

 void replace_Variables(cmdLine* line){
     for(int i=0; i<line->argCount;i++){
         if (strncmp(line->arguments[i], "$", 1)==0){
             var_link* l=search(line->arguments[i]+1);
             if(l==NULL){
                 fprintf(stderr,"var %s not found\n",line->arguments[i]+1);
             }
             else{
                replaceCmdArg(line,i,l->var->value);
             }
         }
     }
}

void delete(char* varName){
    if(head==NULL){
        fprintf(stderr, "variable not found\n");
        return;
    }
    else{
        int found=0;
        var_link* curr = head;
        var_link* prev = NULL;
        while(curr!=NULL){
            if(strcmp(varName,curr->var->name)==0){
                found=1;
                if(prev==NULL){
                    head = head->next;
                    break;
                }
                else{
                    prev->next = curr->next;
                }
            }
            prev=curr;
            curr=curr->next;
        }
        if(found==0)
            fprintf(stderr, "variable not found\n");
        free(curr);
    }
}




