#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char encrypt(char c);
char decrypt(char c);
char xprt(char c);
char cprt(char c);
char my_get(char c);
char quit(char c);

struct fun_desc {
  char *name;
  char (*fun)(char);
};

char quit(char c){
  exit(0);
  return 'a';

}

char my_get(char c){
 return fgetc(stdin);
}

char encrypt(char c){
    if( (c>=0x20) && (c<=0x7E))
        return c+3;
    else return c;
}

char decrypt(char c){
    if( (c>=0x20) && (c<=0x7E))
        return c-3;
    else return c;  
}


char censor(char c) {
    if(c == '!')
        return '.';
    else
        return c;
}

char xprt(char c){
    printf("0x%02x\n",c);
    return c;
}

char cprt(char c){
        if( (c>=0x20) && (c<=0x7E))
            printf("%c\n",c);
        else
            printf("%c\n",'.');
        return c;
}

char* map(char *array, int array_length, char (*f) (char)){
    char* mapped_array = (char*)(malloc(array_length*sizeof(char)));
    int i;
    for(i=0;i<array_length;i++)
        mapped_array[i]=(*f)(array[i]);
    
    return mapped_array;
}

int main(int argc, char **argv){
    struct fun_desc menu[]={ {"Cesnsor",censor} , {"Encrypt",encrypt} , {"Decrypt",decrypt} , {"Print hex",xprt} ,{"Print string",cprt}, {"Get String",my_get} , {"Quit",quit},{NULL,NULL}};
    char* carray=(char*)(malloc(5*sizeof(char))) ;
    *carray='\0';
    int i,choice;
   // char* temp;
    
    while(1){
        //printing menu
        printf("Please choose a function:\n");
        for(i=0;i<7;i++)
            printf("%d) %s\n",i,menu[i].name);
        char input[5]={'\0'};
        fgets(input,5,stdin);
        choice=atoi(input);
        if( (choice)>=0 && (choice)<=6)
            printf("Within bounds\n");
        else
            printf("Not within bounds\n");
        //evaluate the function
        carray = map(carray,5,menu[choice].fun);
        printf("DONE\n");
    }
   

    return 0;
    
}
