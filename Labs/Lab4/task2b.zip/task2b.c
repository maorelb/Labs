#include "util.h"
#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_READ 3
#define STDOUT 1
#define STDIN 0
#define STDERR 2
#define SYS_LSEEK 19
#define SYS_GETDENTS 141
#define SYS_EXIT 1


struct linux_dirent {
    long           d_ino; /*inode number */
    int          d_off; /*offset to the next linux dirent */
    unsigned short d_reclen; /*length of this linux dirent */
    char           d_name[]; /*file name - null terminated */
};

#define BUF_SIZE 1024

extern int system_call(int opcode,...);
void printSc(int id, int returnCode);

int main(int argc, char* argv[],char* envp[]){

    int fd,nread,bpos;
    char buf[BUF_SIZE];
    struct linux_dirent *d;
    int i;
    char p='0';
    char* prefix=""; 
    for(i=1;i<argc;i++){
        if(strncmp(argv[i],"-p",2)==0){
            p='1';
            prefix=&argv[i][2];
        }
    }

    fd = system_call(SYS_OPEN,".",0,0777);
    /* error opening file */    
    if(fd==-1)
        system_call(SYS_EXIT,0x55);

    nread=system_call(SYS_GETDENTS,fd,buf,BUF_SIZE);
    for(bpos=0; bpos<nread ;){
        d=(struct linux_dirent *)(buf +bpos);
       
        /* print files with the given prefix */
        if(p=='0'){
            system_call(SYS_WRITE,STDOUT,d->d_name,strlen(d->d_name) );
            system_call(SYS_WRITE,STDOUT,"\n",1); 
        }
        /* p=='1' and file prefix is prefix */
        else if(strncmp(prefix,d->d_name,strlen(prefix))==0){
            system_call(SYS_WRITE,STDOUT,d->d_name,strlen(d->d_name) );
            system_call(SYS_WRITE,STDOUT,"\n",1); 
        }

        bpos+= d->d_reclen;
    }

    return 0;   
}

void printSc(int id, int returnCode){
    /*char* str=itoa(id);
    system_call(SYS_WRITE,STDERR,"system call id: ",strlen("system call id: "));
    system_call(SYS_WRITE,STDERR,str,strlen(str));
    system_call(SYS_WRITE,STDERR,"\n",1);

    str= itoa(returnCode);
    system_call(SYS_WRITE,STDERR,"system call return value: ",strlen("system call return value: "));
    system_call(SYS_WRITE,STDERR,str,strlen(str));
    system_call(SYS_WRITE,STDERR,"\n",1); */
    return ;

 }
 
