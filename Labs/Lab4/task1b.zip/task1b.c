#include "util.h"

#define SYS_WRITE 4
#define SYS_OPEN 5
#define SYS_READ 3
#define STDOUT 1
#define STDIN 0
#define STDERR 2
#define SYS_LSEEK 19
#define SYS_CLOSE 6

extern int system_call(int opcode,...);
void printSc(int id, int returnCode);

int main(int argc, char* argv[],char* envp[]){
    char c;
    char flag='0';
    int i,bytesReceived,bytesSent,input=STDIN,output=STDOUT;

    for(i=1;i<argc;i++){
        if(strcmp(argv[i],"-D")==0)
            flag='1';  
        
    
    /* file for writing */
        if(strncmp(argv[i],"-o",2)==0){
            output=system_call(SYS_OPEN,argv[i]+2,1,0644);
            /*error opening file */
            if(output==-1)
                return 1;
            }

    /* file for reading */
        if(strncmp(argv[i],"-i",2)==0){
            input=system_call(SYS_OPEN,argv[i]+2,0);
            /*error opening file */
            if(output==-1)
                return 1;
            }
    } 

    /* main loop */
    while(1){
        /* read from input file/stdin */
         bytesReceived=system_call(SYS_READ,input,&c,1);
         if(flag=='1')
             printSc(SYS_READ,bytesReceived);
         /* if there's no more bytes to read exit */
         if(bytesReceived==0)
            return 0;
        /* convert to upper case letter */
         if((c>=65) && (c<=90))
            c=c+32;
        /* print to output file/stdout */
        bytesSent=system_call(SYS_WRITE,output,&c,1);
        if(flag=='1')
            printSc(SYS_WRITE,bytesSent);
    }

    if(output!=STDOUT)
        system_call(SYS_CLOSE,output);
    if(input!=STDIN)
        system_call(SYS_CLOSE,input);

    return 0;
}

void printSc(int id, int returnCode){
    
    char* str=itoa(id);
    /*print id*/
    system_call(SYS_WRITE,STDERR,"system call id: ",strlen("system call id: "));
    system_call(SYS_WRITE,STDERR,str,strlen(str));
    system_call(SYS_WRITE,STDERR,"\n",1);

    str= itoa(returnCode);
    /*print return value*/
    system_call(SYS_WRITE,STDERR,"system call return value: ",strlen("system call return value: "));
    system_call(SYS_WRITE,STDERR,str,strlen(str));
    system_call(SYS_WRITE,STDERR,"\n",1);
    
    return;
 }