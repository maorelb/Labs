#include <elf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

struct fun_desc {
  char *name;
  void (*fun)();
};

void examine_elf_file();
void toggle_debug_mode();
void quit();
void print_section_names();
void relocation_tables();
void print_symbols();
char debug_mode='0';
int fd=-1; //global file descriptor
void *map_start; /* will point to the start of the memory mapped file */
struct stat fd_stat; /* this is needed to  the size of the file */
Elf32_Ehdr *header; /* this will point to the header structure */
Elf32_Shdr *sections; /* this will point to the sections starting address */
char * sh_strtab_p; /*pointer to the first string in str_tab */
int i;

void quit(){
    if(debug_mode=='1')
        printf("quitting\n");
    /* now, we unmap the file */
   munmap(map_start, fd_stat.st_size);
   if(fd!=-1)
        close(fd);
    exit(0);
}

void toggle_debug_mode(){
    switch(debug_mode){
        case '0':
            debug_mode='1';
            break;
        case '1':
            debug_mode='0';
            break;
    }
}

void examine_elf_file(){
//closing current file
    if(fd!=-1)
        close(fd);
    printf("Please enter file name:\n");

    char input[100];
    fgets(input,100,stdin);
    input[strlen(input)-1]='\0'; //remove '\n'

   if( (fd = open(input, O_RDWR)) < 0 ) {
      perror("error in open");
      fd=-1;
      exit(-1);
   }

   if( fstat(fd, &fd_stat) != 0 ) {
      perror("stat failed");
      exit(-1);
   }

   if ( (map_start = mmap(0, fd_stat.st_size, PROT_READ | PROT_WRITE , MAP_SHARED, fd, 0)) == MAP_FAILED ) {
      perror("mmap failed");
      fd=-1;
      exit(-4);
   }

   /* now, the file is mapped starting at map_start.
    * all we need to do is tell *header to point at the same address:
    */
    header = (Elf32_Ehdr *) map_start;
    sections = (Elf32_Shdr *) ((char*)header+header->e_shoff );
    Elf32_Shdr * strtab =(Elf32_Shdr *) &sections[header->e_shstrndx];
    sh_strtab_p = map_start + strtab->sh_offset;
    printf("\n");
	printf("            ELF INFORMATION FOR \"%s\"\n\n", input);

	printf("ELF-Header --------------------\n");

	printf("Magic:");
	for ( int i = 0; i < 3; i++ ) {
		if ( i % 3 == 0 ) {
			printf("\n\t");
		}
		printf("%d:0x%x ", i, header->e_ident[ i ] );
	}
	printf("\n");

	printf("Data encoding scheme:                       %d\n", header->e_version );
    printf("Entry point:                              0x%x\n", header->e_entry );
    printf("section header offset:                      %d\n", header->e_shoff );
    printf("number of section header entries:           %d\n", header->e_shnum );
    printf("size of each section header entry:          %d\n", header->e_shentsize );
    printf("program header table offset:                %d\n", header->e_phoff );
    printf("number of program header entries:           %d\n", header->e_phnum );
    printf("size of each program header entry:          %d\n", header->e_phentsize );

    printf("\n");
}

void print_section_names(){
    Elf32_Shdr *shdr;
    if(fd==-1){
        printf("file invalid\n");
        exit(-1); 
    }

    printf("\nSection Headers:\n");
    printf("[Nr]    name        address         offset     size    type\n");
 
    for (i = 0; i < header->e_shnum; i++ ) {
        printf("\n");
        shdr = (Elf32_Shdr *) ((char*)header+header->e_shoff + i * header->e_shentsize);
        printf("[%d]    %s      0x%x      0x%x      0x%x      %d ", i,
                        sh_strtab_p + sections[i].sh_name,shdr->sh_addr,
                        shdr->sh_offset, shdr->sh_size, shdr->sh_type                                                        );
    }
    printf("\n");
}

void print_symbols(){
    int entries;
    Elf32_Sym* symtab;
    char* symStrTable;
    if(fd==-1){
        printf("file invalid\n");
        exit(-1); }
    for (i = 0; i < header->e_shnum; i++){
        if (sections[i].sh_type == SHT_SYMTAB) {
            symtab = (Elf32_Sym *)((char *)map_start + sections[i].sh_offset);
            entries=sections[i].sh_size / sections[i].sh_entsize;
            symStrTable=((char*) map_start + sections[sections[i].sh_link].sh_offset);

            break; }
    }
    //sections[i].sh_link + symtab[i].st_name
    printf("[inde4x]  value    index    section_name    symbol_name\n"); 
    for(i=0; i<entries;i++)
        printf("[%d]     0x%x        %d           %s               %s \n" 
                                ,i, symtab[i].st_value, symtab[i].st_shndx ,
                               ".symtab",symStrTable + symtab[i].st_name  );    
}
void relocation_tables(){ 
    Elf32_Rel* rel;
    int entries;
    Elf32_Sym* dymtable;
    char* dynStringtable;

    /*saving .dynsym table*/ 
    for(i=0;i<header->e_shnum; i++){
        if(sections[i].sh_type==SHT_DYNSYM){
            printf("found .dynsym table at index %d\n",i);
            dymtable = (Elf32_Sym *)((char *)map_start + sections[i].sh_offset);
            dynStringtable=((char*) map_start + sections[sections[i].sh_link].sh_offset);
            break;
        }
    }
    for (i = 0; i < header->e_shnum; i++){
        if (sections[i].sh_type == SHT_REL) {
            rel = (Elf32_Rel *)((char *)map_start + sections[i].sh_offset);
            entries=sections[i].sh_size / sections[i].sh_entsize;
            printf("relocation table at index %d and number of entries %d\n",i,entries);
            /* PRINTINNG REL TABLE*/
            printf("Offset      Info    Type    Sym.Value   Sym. Name\n");
            for(int j=0 ; j<entries ; j++){
                int index=ELF32_R_SYM(rel[j].r_info);
                printf("%x      %x       %d     %d            %s \n",rel[j].r_offset,
                                        rel[j].r_info,ELF32_R_TYPE(rel[j].r_info),
                                        dymtable[index].st_value,
                                        dynStringtable + dymtable[index].st_name);
            }
        }
    }
}

int main(int argc, char **argv){
    struct fun_desc menu[]={ {"Toggle Debug Mode",toggle_debug_mode} , {"Examine ELF file",examine_elf_file} ,
            {"Print section Names", print_section_names},
            {"Print Symbols", print_symbols},{"Relocation Tables",relocation_tables},
             {"Quit",quit},{NULL,NULL}};
     while(1){
        for(i=0;i<6;i++)
            printf("%d-%s\n",i,menu[i].name);
        char input[5]={'\0'};
        fgets(input,5,stdin);
        int choice=atoi(input);
        if(choice>=0 && choice<=6)
            (menu[choice].fun)();
        else
            printf("Not within bounds\n");
    }
    exit(0);
}




