#include <stdlib.h>
#include <stdio.h>
#include "LineParser.c"
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

#define TERMINATED  -1
#define RUNNING 1
#define SUSPENDED 0

typedef struct process{
    cmdLine* cmd;                         /* the parsed command line*/
    pid_t pid; 		                  /* the process id that is running the command*/
    int status;                           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next;	                  /* next process in chain */
} process;

char *getcwd(char *buf, size_t size);
void execute(cmdLine *pCmdLine);
int execv(const char *path, char *const argv[]);
pid_t waitpid(pid_t pid, int *status, int options);
void addProcess(process** process_list, cmdLine* cmd, pid_t pid);
void printProcessList(process** process_list);
void freeProcessList(process* process_list);
void updateProcessList(process **process_list);
void updateProcessStatus(process* process_list, int pid, int status);
process* list=NULL;
int debugMode=0;

int main(int argc, char** argv){
    pid_t child_pid;
    int ret;
    char buf[2048];
    char* wd;

    for(int i=0; i<argc;i++){
        if(strcmp(argv[i],"-d")==0){
            debugMode=1;
        }
    }
   
    //main loop
    while(1){
        //printing working directory
        wd= getcwd(buf,PATH_MAX);
        printf("%s\n",wd); 
        fgets(buf,2048,stdin); 
        cmdLine* line = parseCmdLines(buf);
        if(strncmp(buf,"quit",4)==0){
            exit(0);
        }
        else if(strncmp(buf,"cd",2)==0 ){
            buf[strlen (buf) - 1] = '\0'; //remove '\n'
            ret = chdir ((buf+3));
            if(ret!=0)
                perror("chdir");          
        }
        else if(strncmp(buf,"procs",5)==0){
            printProcessList(&list);
        }
        else if(strncmp(buf,"wake",4)==0){
			if(kill(atoi(line->arguments[1]), SIGCONT)==0)
				updateProcessStatus(list, atoi(line->arguments[1]), RUNNING);
			else 
                perror("wake");
            continue;
		}
        else if(strncmp(buf,"suspend",7)==0){
			if(kill(atoi(line->arguments[1]), SIGTSTP)==0)
				updateProcessStatus(list, atoi(line->arguments[1]), SUSPENDED);
			else 
                perror("kill");
            continue;
        }
        else if(strncmp(buf,"kill",4)==0){
			if(kill(atoi(line->arguments[1]), SIGINT)==0)
				updateProcessStatus(list, atoi(line->arguments[1]), TERMINATED);
			else 
                perror("Error in kill - kill");
            continue;
		}
        else{
            child_pid=fork(); 
            if(child_pid==0)
                execute(line);
            else{
                addProcess(&list,line,child_pid);
                if(line->blocking==1)
                    waitpid(child_pid,NULL,0); // wait for child process to terminate 
            }
            //freeCmdLines(line);
        }
    }
    return 0;
}

void execute(cmdLine *pCmdLine){
    if(debugMode==1){
        fprintf(stderr,"Pid: %d\n",getpid());
        fprintf(stderr,"Executing command: %s\n",pCmdLine->arguments[0]);
    }
    execvp(pCmdLine->arguments[0],pCmdLine->arguments);
    perror("execv");
    exit(1);
 }


void addProcess(process** process_list, cmdLine* cmd, pid_t pid){
    process* p=(process*)malloc(sizeof(process));
    p->cmd=cmd;
    p->pid=pid;
    p->status=RUNNING;
    p->next=NULL;
    if(*process_list==NULL) 
        *process_list=p;
    else{ //append to the end of list 
        process* temp=*process_list;
        while(temp->next!=NULL)
            temp=temp->next;
        temp->next=p;
    }
   //printf("process number %d was added to list----------\n",pid);
}

void printProcessList(process** process_list){
    //updateProcessList(process_list);
    if(*process_list==NULL){
        printf("list is empty existing...\n");
        return;
    }
    process* temp=*process_list;
    printf("PID\t");
    printf("Command\t\t");
    printf("STATUS\n");
	while (temp != NULL)
	{
        printf("%d\t",temp->pid);
        printf("%s\t\t",temp->cmd->arguments[0]);
        switch(temp->status){
            case -1:
                printf("TERMINATED\n");
                break;
            case 1:
                printf("RUNNING\n");
                break;
            case 0:
                printf("SUSPENDED\n");
                break;
        }
    	temp = temp->next;
	}
    updateProcessList(process_list);
}

void freeProcessList(process* process_list){
    if(process_list==NULL)
        return;
    process* temp=process_list;
    while(temp!=NULL){
        free(temp->cmd);
        process* temp2=temp->next;
        free(temp);
        temp=temp2;
    }
}

void updateProcessList(process **process_list){
    //int status,child_pid;
    process* curr=*process_list;
    pid_t child_pid;
    int status;
    //clear all processes with terminated status
    while(curr!=NULL){
        if(curr->status==TERMINATED){
            process* prev=*process_list;
            process* temp=curr;
            //need to delete head of the list 
            if(prev==curr){
                *process_list=(*process_list)->next;
                freeCmdLines(temp->cmd);
                free(temp);
            }
            else{
                while(prev->next!=curr){
                    prev=prev->next;
                }
                process* next=curr->next;
                prev->next=next;
                freeCmdLines(temp->cmd);
                free(temp);
            }
        }
        curr=curr->next;
    }
    //update status of the processes
    process* temp=*process_list;
    while(temp!=NULL){
        child_pid=waitpid(temp->pid,&status,WNOHANG||WUNTRACED||WCONTINUED); 
            //child terminated normaly or by a signal or had a core dump
            if (WIFCONTINUED(status))
                temp->status=RUNNING;
            else if(WIFEXITED(status)) 
               temp->status=TERMINATED;
              //child was stopped
            else if(WIFSTOPPED(status))
                temp->status=SUSPENDED;
            //child continued 
         temp=temp->next;
        }
}

void updateProcessStatus(process* process_list, int pid, int status){
    process* temp= process_list;
    while(temp!=NULL){
        if(temp->pid==pid){
            temp->status=status;
            break;
        }
        temp=temp->next;
    }
}




