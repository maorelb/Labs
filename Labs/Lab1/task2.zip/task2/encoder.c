#include <stdio.h>
#include <string.h>
#include <stdbool.h>
void printArguments(char** text,int n);
char nextChar(char* text);
int counter=0;

int main(int argc, char** argv){
    char c,encryptedChar;
    int i;
    FILE* input=stdin;
    FILE* output=stdout;
    bool debug=false,encryption=false,substraction=false,addition=false;
    char* encryptionCode;
    char* outputFileName;
    char* inputFileName;

    for(i=1;i<argc;i++){
        if(strncmp(argv[i],"-e",2)==0 || strncmp(argv[i],"+e",2)==0){
            encryption=true;
            addition=argv[i][0]=='+';
            substraction=argv[i][0]=='-';
            encryptionCode=&argv[i][2];
        }
        
        if(strncmp(argv[i],"-o",2)==0){
            outputFileName=&argv[i][2];
            output=fopen(outputFileName,"w");
            if(output==NULL){
                perror("Error in opening file\n");
            return 1;
            }
       }
        if(strcmp(argv[i],"-D")==0){
            debug=true;  
            printArguments(argv,argc);  
        }
        
        if(strncmp(argv[i],"-i",2)==0){
            inputFileName=&argv[i][2];
            input=fopen(inputFileName,"r");
            if(input==NULL){
                perror("Error in opening file\n");
                return 1;
            }
    }

    }
    
    while(( c=fgetc(input))!=EOF){
        if(debug)
            fprintf(stderr,"0x%02X\t",c);
        if(encryption){
            char d=nextChar(encryptionCode);
            if(addition)
                encryptedChar=c+d;
            else if(substraction)
                encryptedChar=c-d;
            fputc(encryptedChar,output);
            if(c=='\n'){
                counter =0;
            }
        }

        if((c>=65) && (c<=90) && !encryption)
            c=c+32;
        
        if(debug)
            fprintf(stderr,"0x%02X\n",c);
        if(!encryption)
            fputc(c,output);
    }
    
    return 0;
}



void printArguments(char** text,int n){
 for(int i=1;i<n;i++)
     fprintf(stderr,"%s ",text[i]);
 printf("\n");
}

char nextChar(char* text){
    char ret=text[counter];
    counter++;
    if(text[counter]=='\0')
        counter=0;
    return ret;
}
