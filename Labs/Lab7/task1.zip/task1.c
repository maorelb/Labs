#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;

void quit(state* s);
void toggle_debug_mode(state* s);
void set_file_name(state* s);
void set_unit_size(state* s);
void load_into_memory(state* s);
void memory_display(state* s);
void save_into_file(state* s);
void file_modify(state* s);
void print_units(FILE* output, char* buffer, int count,int unit_size);


struct fun_desc {
  char *name;
  void (*fun)(state*);
};

void quit(state* s){
    if(s->debug_mode=='1')
        printf("quitting\n");
    
    free(s);
    exit(0);
}

void set_file_name(state* s){
    printf("Please enter file name:\n");
    char input[100];
    fgets(input,100,stdin);
    input[strlen(input)-1]='\0'; //remove '\n' 
    if(s->debug_mode=='1')
        printf("Debug: file name set to '%s'\n",input);
    strcpy(s->file_name,input);
}

void set_unit_size(state* s){
    char input[5];
    printf("enter unit size:\n");
    fgets(input,5,stdin);
    int size=atoi(input);
    if(size!=1 && size!=2 && size!=4){
        printf("error: size is not valid\n");
        return;
    }
    else {
        if(s->debug_mode=='1')
            printf("Debug: set size to %d\n",size);
        s->unit_size=size;
    }
}

void toggle_debug_mode(state* s){
    switch(s->debug_mode){
        case '0':
            s->debug_mode='1';
            break;
        case '1':
            s->debug_mode='0';
            break;
    }
}

void load_into_memory(state* s){
    if(s->file_name==NULL){
        printf("error: file name is NULL\n");
        exit(1);
    }
    FILE* fd=fopen(s->file_name,"r+");
    if(fd==NULL){
        printf("error opening file, exiting...\n");
        exit(1);
    }
    printf("enter location and length\n");
    char input[1000];
    unsigned int location,length;
    fgets(input,1000,stdin);
    sscanf(input, "%x %d",&location,&length);
    if(s->debug_mode=='1')
        printf("file_name: %s  location: %x   length:  %d\n","abc",location,length);

    fseek(fd,(long int)location,SEEK_SET);
    printf("Loaded %d units into memory:\n",length);
    fread(s->mem_buf,s->unit_size,length,fd);
    fseek(fd,0,SEEK_SET); //returns to beginning
    fclose(fd);
}

void memory_display(state* s){
    char input[1000];
    unsigned int addr,u;
    printf("Please enter address and number of units\n");
    fgets(input,1000,stdin);
    sscanf(input, "%x %d",&addr,&u);
    printf("Decimal     Hexadecimal\n");
    printf("=======================\n");
    print_units(stdout, ((s->mem_buf)+addr), u ,s->unit_size);
}

void save_into_file(state* s){
    printf("Please enter <source-address> <target-location> <length>\n");
    char input[1000];
    fgets(input,1000,stdin);
    unsigned int source_address,target_location,length;
    sscanf(input, "%x %x %d",&source_address,&target_location,&length);
    if(s->debug_mode=='1')
        printf("source address:%x     target location:%x    length:%d \n",source_address,target_location,length);
    FILE* fd=fopen(s->file_name,"r+");
    if(fd==NULL){
        printf("error opening file, exiting...\n");
        exit(1);
    }
    fseek(fd,(long int)target_location,SEEK_SET);
    if(s->debug_mode)
        printf("%d units were written to the file\n",length);
    fwrite(s->mem_buf+source_address, s->unit_size, length, fd);
    fclose(fd);
}

void file_modify(state* s){
    printf("enter location and value\n");
    char input[1000];
    fgets(input,1000,stdin);
    unsigned int location,value;
    sscanf(input, "%x %x",&location,&value);
    if(s->debug_mode=='1')
        printf("location: %x     value: %x\n",location,value);
    FILE* fd=fopen(s->file_name,"r+");
    if(fd==NULL){
        printf("error opening file, exiting...\n");
        exit(1);
    }
    fseek(fd,(long int)location,SEEK_SET);
    fwrite(&value, s->unit_size, 1, fd);
    fseek(fd,0,SEEK_SET);
    fclose(fd);
}


char* unit_to_format(int unit) {
    switch (unit) {
        case 1:
            return "%#hhx\n";
        case 2:
            return "%#hx\n";
        case 4:
            return "%#hhx\n";
        default:
            return "Unknown unit";
    }
} 

/* Prints the buffer to screen by converting it to text with printf */
void print_units(FILE* output, char* buffer, int count,int unit_size) {
    char* end = buffer + unit_size*count;
    while (buffer < end) {
        //print ints
        int var = *((int*)(buffer));
        fprintf(output, "%d\t\t\t",var);
        fprintf(output, unit_to_format(unit_size), var);
        buffer += unit_size;
    }
}


int main(int argc, char **argv){
    struct fun_desc menu[]={ {"Toggle Debug Mode",toggle_debug_mode} , {"Set File Name",set_file_name} ,
            {"Set Unit Size",set_unit_size}, {"Load Into Memory",load_into_memory} ,{"Memory Display",memory_display},
            {"Save Into File",save_into_file},{"File Modify",file_modify},
            {"Quit",quit},{NULL,NULL}};
    int i,choice;
    state* file=(state*)(malloc(sizeof(state)));
    file->debug_mode='0';
    file->unit_size=1;
    while(1){
        for(i=0;i<8;i++)
            printf("%d-%s\n",i,menu[i].name);
        char input[5]={'\0'};
        fgets(input,5,stdin);
        choice=atoi(input);
        if(choice>=0 && choice<=7)
            (menu[choice].fun)(file);
        else
            printf("Not within bounds\n");
    }
    free(file);
    return 0;
}


